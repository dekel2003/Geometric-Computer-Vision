function plot_curve_points( X, Y )
hold on, fill(X,Y,'r'), plot( X, Y, '+b' ), hold off;
end

